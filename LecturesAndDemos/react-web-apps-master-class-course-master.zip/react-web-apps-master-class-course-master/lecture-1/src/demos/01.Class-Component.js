import React from 'react';

class ClassComponent extends React.Component {
  state = {};
  render() {
    return <div>I am Class Component</div>;
  }
}

export { ClassComponent };
