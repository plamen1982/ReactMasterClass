import React from 'react';

const FunctionComponent = () => <div>I am Function Component</div>;

export default { FunctionComponent };
