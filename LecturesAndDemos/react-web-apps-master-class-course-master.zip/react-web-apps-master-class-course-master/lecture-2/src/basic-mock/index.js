export const giveMeRandom = () => Math.random();
