import React from 'react';
import MemeGenerator from '../components/MemeGenerator';

export const Basic = () => <MemeGenerator />;

export default {
  title: 'MemeGenerator',
};
