import React from 'react';
import ReactDOM from 'react-dom';
import { CodeSplitting } from './App';

ReactDOM.render(<CodeSplitting />, document.getElementById('root'));
