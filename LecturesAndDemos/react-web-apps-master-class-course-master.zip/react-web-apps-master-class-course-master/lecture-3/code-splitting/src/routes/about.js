import React from 'react';

console.log('Loading About');

export default () => <div>About</div>;
