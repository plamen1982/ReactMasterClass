import React from 'react';

console.log('Loading News');

export default () => <div>News</div>;
