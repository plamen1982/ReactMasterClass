import React from 'react';
import ReactDOM from 'react-dom';

import { Hooks } from './App';

ReactDOM.render(<Hooks />, document.getElementById('root'));
