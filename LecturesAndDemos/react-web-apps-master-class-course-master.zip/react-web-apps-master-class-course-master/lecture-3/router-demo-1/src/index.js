import React from 'react';
import ReactDOM from 'react-dom';
import { RouteMatcher } from './App';

ReactDOM.render(<RouteMatcher />, document.getElementById('root'));
