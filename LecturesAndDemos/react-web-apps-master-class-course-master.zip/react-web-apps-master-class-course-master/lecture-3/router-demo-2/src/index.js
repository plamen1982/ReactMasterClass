import React from 'react';
import ReactDOM from 'react-dom';

import { RouteNavigation } from './App';

ReactDOM.render(<RouteNavigation />, document.getElementById('root'));
