import React from 'react';

import Button from '../components/Button';

const ButtonDemo = () => (
  <Button />
);

export default ButtonDemo;
