import React from 'react';

import './styles.css';

const Button = () => (
  <button className="button">Button</button>
);

export default Button;