import React from 'react';

import AlertWithHover from '../components/AlertWithHover';

const AlertWithHoverDemo = () => (
  <div>
    <AlertWithHover>
      Hover me!
    </AlertWithHover>
  </div>
);

export default AlertWithHoverDemo;